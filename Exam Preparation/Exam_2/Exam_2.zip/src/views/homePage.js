const homeSection = document.getElementById("home");

export function showHome(context) {
    context.render(homeSection, "");
}