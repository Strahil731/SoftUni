const searchSection = document.getElementById("search");
let ctx = null;

export function showSearch(context){
    ctx = context;
    ctx.render(searchSection);
}